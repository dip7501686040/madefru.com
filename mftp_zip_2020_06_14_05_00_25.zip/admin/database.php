<?php
$con=mysqli_connect("sql204.epizy.com","epiz_24451952","Qawsed12345","epiz_24451952_madefru");
if(mysqli_connect_errno()){
	echo "faild to connect to mysql".mysqli_connect_errno();
}
mysqli_select_db($con,"epiz_24451952_madefru");
?>
